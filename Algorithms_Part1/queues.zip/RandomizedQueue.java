/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */


import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;


public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] queue;
    private int size;


    public RandomizedQueue() {
        queue = (Item[]) new Object[2];
        size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void enqueue(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        if (size == queue.length) {
            Item[] newqueue = (Item[]) new Object[queue.length * 2];
            for (int i = 0; i < size; i++) {
                newqueue[i] = queue[i];
            }
            queue = newqueue;
        }
        queue[size] = item;
        size++;
    }

    public Item dequeue() {
        if (isEmpty()) {
            throw new java.util.NoSuchElementException();
        }
        int x = (int) (Math.random() * size);
        Item item = queue[x];

        queue[x] = queue[size - 1];
        queue[size - 1] = null;
        size--;
        if (size > 0 && (size == queue.length / 4)) {
            Item[] newqueue = (Item[]) new Object[queue.length / 2];
            for (int i = 0; i < size; i++) {
                newqueue[i] = queue[i];
            }
            queue = newqueue;
        }
        return item;

    }

    public Item sample() {
        if (isEmpty()) {
            throw new java.util.NoSuchElementException();
        }
        int x = (int) (Math.random() * size);
        return queue[x];
    }

    private class RandomizedQueueIterator implements Iterator<Item> {
        private Item[] copy;
        private int x;

        public RandomizedQueueIterator() {
            x = size;
            copy = (Item[]) new Object[x];

            for (int i = 0; i < x; i++) {
                copy[i] = queue[i];
            }
        }

        public boolean hasNext() {
            return x > 0;
        }

        public Item next() {
            if (!hasNext()) {
                throw new java.util.NoSuchElementException();
            }
            int index = (int) (Math.random() * x);
            Item current = copy[index];
            copy[index] = copy[x - 1];
            copy[x - 1] = null;
            x--;
            return current;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

    }

    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }

    public static void main(String[] args) {
        String name = "dohyun";
        StdOut.print(name);
    }

}
