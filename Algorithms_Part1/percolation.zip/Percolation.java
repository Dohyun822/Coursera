/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private enum Id {
        FALSE,
        TRUE,
    }

    private Id[][] ids;
    private final WeightedQuickUnionUF unionUF;
    private int opened = 0;

    public Percolation(int n) {
        if (n <= 0) {
            throw new java.lang.IllegalArgumentException();
        }
        opened = 0;
        ids = new Id[n][n];
        unionUF = new WeightedQuickUnionUF(n * n + 2);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                ids[i][j] = Id.FALSE;
            }
        }
    }

    public void open(int row, int col) {
        if (row < 1 || row > ids.length || col < 1 || col > ids.length) {
            throw new java.lang.IllegalArgumentException();
        }
        ids[row - 1][col - 1] = Id.TRUE;
        if (row == 1) {
            unionUF.union(col - 1, ids.length * ids.length);
        }
        if (row == ids.length) {
            unionUF.union((ids.length - 1) * ids.length + (col - 1), ids.length * ids.length + 1);
        }
        opened++;

        unionTO(row, col, row - 1, col);
        unionTO(row, col, row, col + 1);
        unionTO(row, col, row + 1, col);
        unionTO(row, col, row, col - 1);

    }

    private void unionTO(int i, int j, int i2, int j2) {
        if (i2 < 1 || i2 > ids.length || j2 < 1 || j2 > ids.length) {
            return;
        }
        if (isBlocked(i2, j2)) {
            return;
        }
        unionUF.union((i - 1) * ids.length + (j - 1), (i2 - 1) * ids.length + (j2 - 1));
    }

    private boolean isBlocked(int row, int col) {
        if (row < 1 || row > ids.length || col < 1 || col > ids.length) {
            throw new java.lang.IllegalArgumentException();
        }
        return ids[row - 1][col - 1] == Id.FALSE;
    }

    public boolean isOpen(int row, int col) {
        if (row < 1 || row > ids.length || col < 1 || col > ids.length) {
            throw new java.lang.IllegalArgumentException();
        }
        return ids[row - 1][col - 1] == Id.TRUE;
    }

    public boolean isFull(int row, int col) {
        if (row < 1 || row > ids.length || col < 1 || col > ids.length) {
            throw new java.lang.IllegalArgumentException();
        }
        boolean check = unionUF.find(ids.length * ids.length) == unionUF
                .find((row - 1) * ids.length + (col - 1));

        boolean open = isOpen(row, col);
        return check && open;
    }

    public int numberOfOpenSites() {
        return opened;
    }

    public boolean percolates() {
        return unionUF.find(ids.length * ids.length) == unionUF.find((ids.length * ids.length) + 1);
    }

    public static void main(String[] args) {

    }
}
